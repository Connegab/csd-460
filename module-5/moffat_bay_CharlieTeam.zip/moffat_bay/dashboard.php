<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

requireLogin();

$user = getLoggedInUser();
$displayName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));

if ($displayName === '') {
    $displayName = $user['email'] ?? 'Guest';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moffat Bay Lodge | Dashboard</title>
    <link rel="stylesheet" href="login_style.css">
</head>
<body>
    <header class="site-header">
        <a class="site-title" href="dashboard.php">Moffat Bay Lodge</a>
        <nav class="nav" aria-label="Primary navigation">
            <a href="#">Reservations</a>
            <a href="#">Activities</a>
            <a href="#">Dining &amp; More</a>
            <a href="#">Support</a>
        </nav>
        <a class="header-button" href="logout.php">Log Out</a>
    </header>

    <main class="dashboard-main">
        <section class="dashboard-card">
            <p class="hero-kicker dashboard-kicker">Signed In</p>
            <h1>Welcome, <?php echo htmlspecialchars($displayName); ?></h1>
            <p class="dashboard-copy">Your login is working. From here, you can build reservations, rewards, account settings, and customer support features.</p>

            <div class="dashboard-meta">
                <div class="dashboard-item">
                    <span class="dashboard-label">Email</span>
                    <strong><?php echo htmlspecialchars((string) ($user['email'] ?? '')); ?></strong>
                </div>

                <div class="dashboard-item">
                    <span class="dashboard-label">Customer ID</span>
                    <strong><?php echo htmlspecialchars((string) ($user['customer_id'] ?? '')); ?></strong>
                </div>
            </div>
        </section>
    </main>
</body>
</html>

