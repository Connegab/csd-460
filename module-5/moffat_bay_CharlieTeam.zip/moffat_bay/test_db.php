<?php
require 'db.php';

$stmt = $pdo->query("SELECT 1");
echo "Query worked.";