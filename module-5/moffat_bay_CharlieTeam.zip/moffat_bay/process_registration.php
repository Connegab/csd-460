<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from your HTML form
    $fname = trim($_POST['first_name']);
    $lname = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['telephone']);
    $pass  = $_POST['password'];
    $conf  = $_POST['password_confirm'];

    // Basic Validation
    if ($pass !== $conf) {
        header("Location: registration.php?error=Passwords do not match");
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($pass, PASSWORD_DEFAULT);

    try {
        $sql = "INSERT INTO customers (email, first_name, last_name, telephone, password_hash) 
                VALUES (:email, :fname, :lname, :phone, :pass_hash)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'email'     => $email,
            'fname'     => $fname,
            'lname'     => $lname,
            'phone'     => $phone,
            'pass_hash' => $hashed_password
        ]);

        header("Location: registration.php?success=Welcome to the Lodge!");
        exit();

    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { 
            header("Location: registration.php?error=This email is already registered.");
        } else {
            header("Location: registration.php?error=Registration failed. Please try again.");
        }
        exit();
    }
}